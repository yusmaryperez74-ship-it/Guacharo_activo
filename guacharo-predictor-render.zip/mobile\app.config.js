export default {
  expo: {
    name: "Guacharo Predictor",
    slug: "guacharo-predictor",
    version: "1.0.1",
    orientation: "portrait",
    icon: "./assets/icon.png",
    userInterfaceStyle: "automatic", // Soporte para modo oscuro automático

    splash: {
      image: "./assets/splash.png",
      resizeMode: "contain",
      backgroundColor: "#8B5CF6" // Color morado del tema
    },

    android: {
      package: "com.guacharo.predictor",
      versionCode: 2,
      permissions: [],
      adaptiveIcon: {
        foregroundImage: "./assets/adaptive-icon.png",
        backgroundColor: "#8B5CF6" // Color morado del tema
      }
    },

    assetBundlePatterns: ["**/*"],

    extra: {
      eas: {
        projectId: "475ed599-4e43-40f3-b165-5e81b673f665"
      }
    }
  }
};
