import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  Share,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import theme from '../theme';

const FAVORITES_KEY = '@guacharo_favorites';

export default function FavoritesScreen() {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    cargarFavoritos();
  }, []);

  const cargarFavoritos = async () => {
    try {
      const data = await AsyncStorage.getItem(FAVORITES_KEY);
      if (data) {
        setFavorites(JSON.parse(data));
      }
    } catch (error) {
      console.error('Error cargando favoritos:', error);
    }
  };

  const guardarFavoritos = async (newFavorites) => {
    try {
      await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
      setFavorites(newFavorites);
    } catch (error) {
      console.error('Error guardando favoritos:', error);
    }
  };

  const agregarFavorito = () => {
    Alert.prompt(
      'Agregar Favorito',
      'Ingresa el número (00-36):',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Agregar',
          onPress: (numero) => {
            const num = parseInt(numero);
            if (num >= 0 && num <= 36) {
              const existe = favorites.find(f => f.numero === num);
              if (existe) {
                Alert.alert('Error', 'Este número ya está en favoritos');
                return;
              }
              
              const nuevoFavorito = {
                id: Date.now().toString(),
                numero: num,
                fechaAgregado: new Date().toISOString(),
              };
              
              guardarFavoritos([...favorites, nuevoFavorito]);
            } else {
              Alert.alert('Error', 'Número inválido. Debe estar entre 00 y 36');
            }
          },
        },
      ],
      'plain-text'
    );
  };

  const eliminarFavorito = (id) => {
    Alert.alert(
      'Eliminar Favorito',
      '¿Estás seguro de eliminar este número de favoritos?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Eliminar',
          style: 'destructive',
          onPress: () => {
            const newFavorites = favorites.filter(f => f.id !== id);
            guardarFavoritos(newFavorites);
          },
        },
      ]
    );
  };

  const compartirFavoritos = async () => {
    if (favorites.length === 0) {
      Alert.alert('Sin Favoritos', 'No tienes números favoritos para compartir');
      return;
    }

    const numeros = favorites.map(f => f.numero.toString().padStart(2, '0')).join(', ');
    const mensaje = `🔮 Mis números favoritos de Guácharo Activo:\n\n${numeros}\n\n¡Buena suerte! 🍀`;

    try {
      await Share.share({
        message: mensaje,
      });
    } catch (error) {
      console.error('Error compartiendo:', error);
    }
  };

  const renderItem = ({ item, index }) => {
    const gradientColors = index % 3 === 0 
      ? theme.gradients.primary 
      : index % 3 === 1 
      ? theme.gradients.secondary 
      : theme.gradients.accent;

    return (
      <View style={styles.card}>
        <LinearGradient
          colors={gradientColors}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.numeroContainer}
        >
          <Text style={styles.numero}>
            {item.numero.toString().padStart(2, '0')}
          </Text>
        </LinearGradient>

        <View style={styles.infoContainer}>
          <Text style={styles.label}>Número Favorito</Text>
          <Text style={styles.fecha}>
            Agregado: {new Date(item.fechaAgregado).toLocaleDateString()}
          </Text>
        </View>

        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => eliminarFavorito(item.id)}
        >
          <Text style={styles.deleteIcon}>🗑️</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[theme.colors.surface, theme.colors.background]}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.title}>⭐ Favoritos</Text>
            <Text style={styles.subtitle}>
              {favorites.length} {favorites.length === 1 ? 'número' : 'números'}
            </Text>
          </View>
          <TouchableOpacity onPress={compartirFavoritos} style={styles.shareButton}>
            <Text style={styles.shareIcon}>📤</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {favorites.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>⭐</Text>
          <Text style={styles.emptyTitle}>Sin Favoritos</Text>
          <Text style={styles.emptyText}>
            Agrega tus números favoritos para tenerlos siempre a mano
          </Text>
          <TouchableOpacity style={styles.addButton} onPress={agregarFavorito}>
            <LinearGradient
              colors={theme.gradients.primary}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.addButtonGradient}
            >
              <Text style={styles.addButtonText}>+ Agregar Favorito</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <FlatList
            data={favorites}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContainer}
            showsVerticalScrollIndicator={false}
          />
          
          <TouchableOpacity style={styles.fab} onPress={agregarFavorito}>
            <LinearGradient
              colors={theme.gradients.primary}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.fabGradient}
            >
              <Text style={styles.fabIcon}>+</Text>
            </LinearGradient>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    paddingTop: theme.spacing.lg,
    paddingBottom: theme.spacing.md,
    paddingHorizontal: theme.spacing.lg,
    ...theme.shadows.sm,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontSize: theme.typography.fontSize.heading,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: theme.typography.fontSize.md,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    fontWeight: theme.typography.fontWeight.medium,
  },
  shareButton: {
    padding: theme.spacing.sm,
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.round,
    ...theme.shadows.sm,
  },
  shareIcon: {
    fontSize: 24,
  },
  listContainer: {
    padding: theme.spacing.lg,
  },
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.xl,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    ...theme.shadows.md,
  },
  numeroContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    ...theme.shadows.colored,
  },
  numero: {
    fontSize: 28,
    fontWeight: theme.typography.fontWeight.extrabold,
    color: theme.colors.textWhite,
  },
  infoContainer: {
    flex: 1,
    marginLeft: theme.spacing.lg,
  },
  label: {
    fontSize: theme.typography.fontSize.md,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    marginBottom: theme.spacing.xs,
  },
  fecha: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textSecondary,
  },
  deleteButton: {
    padding: theme.spacing.sm,
  },
  deleteIcon: {
    fontSize: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.xl,
  },
  emptyIcon: {
    fontSize: 80,
    marginBottom: theme.spacing.lg,
  },
  emptyTitle: {
    fontSize: theme.typography.fontSize.title,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    marginBottom: theme.spacing.sm,
  },
  emptyText: {
    fontSize: theme.typography.fontSize.md,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginBottom: theme.spacing.xl,
    lineHeight: 22,
  },
  addButton: {
    borderRadius: theme.borderRadius.xl,
    overflow: 'hidden',
    ...theme.shadows.lg,
  },
  addButtonGradient: {
    paddingHorizontal: theme.spacing.xl,
    paddingVertical: theme.spacing.lg,
  },
  addButtonText: {
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textWhite,
  },
  fab: {
    position: 'absolute',
    right: theme.spacing.lg,
    bottom: theme.spacing.lg,
    borderRadius: 32,
    overflow: 'hidden',
    ...theme.shadows.xl,
  },
  fabGradient: {
    width: 64,
    height: 64,
    justifyContent: 'center',
    alignItems: 'center',
  },
  fabIcon: {
    fontSize: 32,
    color: theme.colors.textWhite,
    fontWeight: theme.typography.fontWeight.bold,
  },
});
