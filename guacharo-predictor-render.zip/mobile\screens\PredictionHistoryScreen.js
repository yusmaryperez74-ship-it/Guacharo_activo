import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import theme from '../theme';
import { getAnimalIcon } from '../utils/animalIcons';

const PREDICTIONS_KEY = '@guacharo_predictions_history';

export default function PredictionHistoryScreen() {
  const styles = createStyles(theme);
  const [history, setHistory] = useState([]);
  const [stats, setStats] = useState({ total: 0, aciertos: 0, precision: 0 });

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const data = await AsyncStorage.getItem(PREDICTIONS_KEY);
      if (data) {
        const parsedHistory = JSON.parse(data);
        setHistory(parsedHistory);
        calculateStats(parsedHistory);
      }
    } catch (error) {
      console.error('Error loading history:', error);
    }
  };

  const calculateStats = (historyData) => {
    const total = historyData.length;
    const aciertos = historyData.filter(item => item.acerto).length;
    const precision = total > 0 ? ((aciertos / total) * 100).toFixed(1) : 0;
    
    setStats({ total, aciertos, precision });
  };

  const clearHistory = () => {
    Alert.alert(
      'Limpiar Historial',
      '¿Estás seguro de eliminar todo el historial de predicciones?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Eliminar',
          style: 'destructive',
          onPress: async () => {
            try {
              await AsyncStorage.removeItem(PREDICTIONS_KEY);
              setHistory([]);
              setStats({ total: 0, aciertos: 0, precision: 0 });
              Alert.alert('✅ Listo', 'Historial eliminado');
            } catch (error) {
              Alert.alert('Error', 'No se pudo eliminar el historial');
            }
          },
        },
      ]
    );
  };

  const renderItem = ({ item, index }) => {
    const animalIcon = getAnimalIcon(item.animal);
    const gradientColors = item.acerto 
      ? theme.gradients.success 
      : ['#6B7280', '#9CA3AF'];

    return (
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <View style={styles.dateInfo}>
            <Text style={styles.dateText}>📅 {item.fecha}</Text>
            <Text style={styles.timeText}>🕐 {item.hora}</Text>
          </View>
          <View style={[styles.badge, item.acerto ? styles.badgeSuccess : styles.badgeFail]}>
            <Text style={styles.badgeText}>
              {item.acerto ? '✅ Acertó' : '❌ Falló'}
            </Text>
          </View>
        </View>

        <View style={styles.cardBody}>
          <View style={styles.predictionSection}>
            <Text style={styles.sectionLabel}>Predicción</Text>
            <View style={styles.numberRow}>
              <LinearGradient
                colors={theme.gradients.primary}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.numberCircle}
              >
                <Text style={styles.numberText}>{item.numero}</Text>
              </LinearGradient>
              <View style={styles.animalInfo}>
                <Text style={styles.animalIcon}>{animalIcon}</Text>
                <Text style={styles.animalText}>{item.animal}</Text>
              </View>
            </View>
          </View>

          {item.resultado && (
            <View style={styles.resultSection}>
              <Text style={styles.sectionLabel}>Resultado Real</Text>
              <View style={styles.numberRow}>
                <LinearGradient
                  colors={gradientColors}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.numberCircleSmall}
                >
                  <Text style={styles.numberTextSmall}>{item.resultado.numero}</Text>
                </LinearGradient>
                <Text style={styles.resultText}>{item.resultado.animal}</Text>
              </View>
            </View>
          )}
        </View>

        <View style={styles.cardFooter}>
          <Text style={styles.scoreText}>
            Score: {(item.score * 100).toFixed(1)}%
          </Text>
          <Text style={styles.rankingText}>
            Ranking: #{item.ranking}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[theme.colors.surface, theme.colors.background]}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.title}>📝 Historial de Predicciones</Text>
            <Text style={styles.subtitle}>{history.length} predicciones guardadas</Text>
          </View>
          {history.length > 0 && (
            <TouchableOpacity onPress={clearHistory} style={styles.clearButton}>
              <Text style={styles.clearIcon}>🗑️</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Estadísticas */}
        {history.length > 0 && (
          <View style={styles.statsContainer}>
            <View style={styles.statBox}>
              <Text style={styles.statValue}>{stats.total}</Text>
              <Text style={styles.statLabel}>Total</Text>
            </View>
            <View style={styles.statBox}>
              <Text style={[styles.statValue, { color: theme.colors.success }]}>
                {stats.aciertos}
              </Text>
              <Text style={styles.statLabel}>Aciertos</Text>
            </View>
            <View style={styles.statBox}>
              <Text style={[styles.statValue, { color: theme.colors.primary }]}>
                {stats.precision}%
              </Text>
              <Text style={styles.statLabel}>Precisión</Text>
            </View>
          </View>
        )}
      </LinearGradient>

      {history.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>📝</Text>
          <Text style={styles.emptyTitle}>Sin Historial</Text>
          <Text style={styles.emptyText}>
            Las predicciones que guardes aparecerán aquí con su resultado
          </Text>
        </View>
      ) : (
        <FlatList
          data={history}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const createStyles = (theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    paddingTop: theme.spacing.lg,
    paddingBottom: theme.spacing.md,
    paddingHorizontal: theme.spacing.lg,
    ...theme.shadows.sm,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  title: {
    fontSize: theme.typography.fontSize.heading,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: theme.typography.fontSize.md,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    fontWeight: theme.typography.fontWeight.medium,
  },
  clearButton: {
    padding: theme.spacing.sm,
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.round,
    ...theme.shadows.sm,
  },
  clearIcon: {
    fontSize: 24,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: theme.spacing.md,
    marginTop: theme.spacing.md,
  },
  statBox: {
    flex: 1,
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    alignItems: 'center',
    ...theme.shadows.sm,
  },
  statValue: {
    fontSize: theme.typography.fontSize.title,
    fontWeight: theme.typography.fontWeight.extrabold,
    color: theme.colors.textPrimary,
  },
  statLabel: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    fontWeight: theme.typography.fontWeight.medium,
  },
  listContainer: {
    padding: theme.spacing.lg,
  },
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.xl,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.md,
    ...theme.shadows.md,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
    paddingBottom: theme.spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  dateInfo: {
    flexDirection: 'row',
    gap: theme.spacing.md,
  },
  dateText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textSecondary,
  },
  timeText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textPrimary,
    fontWeight: theme.typography.fontWeight.bold,
  },
  badge: {
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.round,
  },
  badgeSuccess: {
    backgroundColor: theme.colors.success + '20',
  },
  badgeFail: {
    backgroundColor: theme.colors.error + '20',
  },
  badgeText: {
    fontSize: theme.typography.fontSize.xs,
    fontWeight: theme.typography.fontWeight.bold,
  },
  cardBody: {
    gap: theme.spacing.md,
  },
  predictionSection: {
    gap: theme.spacing.sm,
  },
  resultSection: {
    gap: theme.spacing.sm,
    paddingTop: theme.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  sectionLabel: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.textSecondary,
    fontWeight: theme.typography.fontWeight.semibold,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  numberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.md,
  },
  numberCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    ...theme.shadows.colored,
  },
  numberText: {
    fontSize: 24,
    fontWeight: theme.typography.fontWeight.extrabold,
    color: theme.colors.textWhite,
  },
  numberCircleSmall: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  numberTextSmall: {
    fontSize: 18,
    fontWeight: theme.typography.fontWeight.extrabold,
    color: theme.colors.textWhite,
  },
  animalInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.xs,
    flex: 1,
  },
  animalIcon: {
    fontSize: 20,
  },
  animalText: {
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
  },
  resultText: {
    fontSize: theme.typography.fontSize.md,
    color: theme.colors.textSecondary,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: theme.spacing.sm,
    paddingTop: theme.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  scoreText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textSecondary,
    fontWeight: theme.typography.fontWeight.semibold,
  },
  rankingText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textSecondary,
    fontWeight: theme.typography.fontWeight.semibold,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.xl,
  },
  emptyIcon: {
    fontSize: 80,
    marginBottom: theme.spacing.lg,
  },
  emptyTitle: {
    fontSize: theme.typography.fontSize.title,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    marginBottom: theme.spacing.sm,
  },
  emptyText: {
    fontSize: theme.typography.fontSize.md,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
});
