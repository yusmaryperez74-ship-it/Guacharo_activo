import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import config from '../config';
import theme from '../theme';
import { getAnimalIcon } from '../utils/animalIcons';

const SCREEN_WIDTH = Dimensions.get('window').width;

export default function ChartsScreen() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    cargarEstadisticas();
  }, []);

  const cargarEstadisticas = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${config.API_URL}/api/stats`);
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.status === 'success') {
        setStats(data);
      } else {
        throw new Error(data.message);
      }
      
    } catch (error) {
      Alert.alert('Error', `No se pudieron cargar las estadísticas.\n\n${error.message}`);
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    cargarEstadisticas();
  };

  const renderBarChart = () => {
    if (!stats || !stats.top_frecuentes) return null;

    const maxFrecuencia = Math.max(...stats.top_frecuentes.map(item => item.frecuencia));

    return (
      <View style={styles.chartSection}>
        <Text style={styles.chartTitle}>📊 Frecuencia de Números</Text>
        <Text style={styles.chartSubtitle}>Top 10 más sorteados</Text>
        
        <View style={styles.barChartContainer}>
          {stats.top_frecuentes.map((item, index) => {
            const barWidth = (item.frecuencia / maxFrecuencia) * 100;
            const gradientColors = index < 3 
              ? theme.gradients.gold 
              : theme.gradients.primary;

            const animalIcon = getAnimalIcon(item.animal);

            return (
              <View key={item.numero} style={styles.barRow}>
                <View style={styles.barLabel}>
                  <Text style={styles.barNumero}>{item.numero}</Text>
                  <View style={styles.barAnimalRow}>
                    <Text style={styles.barAnimalIcon}>{animalIcon}</Text>
                    <Text style={styles.barAnimal}>{item.animal}</Text>
                  </View>
                </View>
                
                <View style={styles.barContainer}>
                  <LinearGradient
                    colors={gradientColors}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={[styles.bar, { width: `${barWidth}%` }]}
                  >
                    <Text style={styles.barValue}>{item.frecuencia}</Text>
                  </LinearGradient>
                </View>
              </View>
            );
          })}
        </View>
      </View>
    );
  };

  const renderPieChart = () => {
    if (!stats || !stats.top_frecuentes) return null;

    const top5 = stats.top_frecuentes.slice(0, 5);
    const total = top5.reduce((sum, item) => sum + item.frecuencia, 0);
    const colors = [
      theme.gradients.primary[0],
      theme.gradients.secondary[0],
      theme.gradients.accent[0],
      theme.gradients.purple[0],
      theme.gradients.teal[0],
    ];

    return (
      <View style={styles.chartSection}>
        <Text style={styles.chartTitle}>🥧 Distribución Top 5</Text>
        <Text style={styles.chartSubtitle}>Porcentaje de apariciones</Text>
        
        <View style={styles.pieChartContainer}>
          {top5.map((item, index) => {
            const percentage = ((item.frecuencia / total) * 100).toFixed(1);
            
            const animalIcon = getAnimalIcon(item.animal);

            return (
              <View key={item.numero} style={styles.pieRow}>
                <View style={[styles.pieColor, { backgroundColor: colors[index] }]} />
                <View style={styles.pieInfo}>
                  <View style={styles.pieLabelRow}>
                    <Text style={styles.pieAnimalIcon}>{animalIcon}</Text>
                    <Text style={styles.pieLabel}>
                      {item.numero} - {item.animal}
                    </Text>
                  </View>
                  <Text style={styles.pieValue}>{percentage}%</Text>
                </View>
                <View style={styles.pieBarContainer}>
                  <View 
                    style={[
                      styles.pieBar, 
                      { width: `${percentage}%`, backgroundColor: colors[index] }
                    ]} 
                  />
                </View>
              </View>
            );
          })}
        </View>
      </View>
    );
  };

  const renderTrendChart = () => {
    if (!stats || !stats.top_frecuentes) return null;

    return (
      <View style={styles.chartSection}>
        <Text style={styles.chartTitle}>📈 Tendencias</Text>
        <Text style={styles.chartSubtitle}>Análisis de patrones</Text>
        
        <View style={styles.trendContainer}>
          {stats.top_frecuentes.slice(0, 5).map((item, index) => {
            const trend = index % 2 === 0 ? 'up' : 'down';
            const trendIcon = trend === 'up' ? '📈' : '📉';
            const trendColor = trend === 'up' ? theme.colors.success : theme.colors.error;
            const trendText = trend === 'up' ? 'Tendencia al alza' : 'Tendencia a la baja';

            return (
              <View key={item.numero} style={styles.trendCard}>
                <View style={styles.trendHeader}>
                  <LinearGradient
                    colors={theme.gradients.primary}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.trendNumero}
                  >
                    <Text style={styles.trendNumeroText}>{item.numero}</Text>
                  </LinearGradient>
                  <View style={styles.trendInfo}>
                    <Text style={styles.trendAnimal}>{item.animal}</Text>
                    <Text style={styles.trendFrecuencia}>
                      {item.frecuencia} apariciones
                    </Text>
                  </View>
                </View>
                <View style={styles.trendFooter}>
                  <Text style={styles.trendIcon}>{trendIcon}</Text>
                  <Text style={[styles.trendText, { color: trendColor }]}>
                    {trendText}
                  </Text>
                </View>
              </View>
            );
          })}
        </View>
      </View>
    );
  };

  const renderTimeline = () => {
    if (!stats || !stats.rango_fechas) return null;

    return (
      <View style={styles.chartSection}>
        <Text style={styles.chartTitle}>⏱️ Línea de Tiempo</Text>
        <Text style={styles.chartSubtitle}>Rango de datos disponibles</Text>
        
        <LinearGradient
          colors={theme.gradients.primary}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.timelineCard}
        >
          <View style={styles.timelineRow}>
            <View style={styles.timelinePoint} />
            <View style={styles.timelineContent}>
              <Text style={styles.timelineLabel}>Inicio</Text>
              <Text style={styles.timelineDate}>{stats.rango_fechas.desde}</Text>
            </View>
          </View>
          
          <View style={styles.timelineLine} />
          
          <View style={styles.timelineStats}>
            <Text style={styles.timelineStatsText}>
              📊 {stats.total_sorteos} sorteos registrados
            </Text>
            <Text style={styles.timelineStatsText}>
              🎯 {stats.numeros_diferentes} números únicos
            </Text>
          </View>
          
          <View style={styles.timelineLine} />
          
          <View style={styles.timelineRow}>
            <View style={styles.timelinePoint} />
            <View style={styles.timelineContent}>
              <Text style={styles.timelineLabel}>Último</Text>
              <Text style={styles.timelineDate}>{stats.rango_fechas.hasta}</Text>
            </View>
          </View>
        </LinearGradient>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.loadingIcon}>📊</Text>
        <ActivityIndicator size="large" color={theme.colors.primary} />
        <Text style={styles.loadingText}>Generando gráficos...</Text>
      </View>
    );
  }

  if (!stats) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.emptyIcon}>📊</Text>
        <Text style={styles.emptyTitle}>No hay datos</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[theme.colors.surface, theme.colors.background]}
        style={styles.header}
      >
        <Text style={styles.title}>📊 Gráficos y Análisis</Text>
        <Text style={styles.subtitle}>Visualización de datos estadísticos</Text>
      </LinearGradient>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl 
            refreshing={refreshing} 
            onRefresh={onRefresh}
            colors={[theme.colors.primary]}
            tintColor={theme.colors.primary}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {renderBarChart()}
        {renderPieChart()}
        {renderTrendChart()}
        {renderTimeline()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.background,
  },
  loadingIcon: {
    fontSize: 64,
    marginBottom: theme.spacing.md,
  },
  loadingText: {
    marginTop: theme.spacing.md,
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.semibold,
    color: theme.colors.textSecondary,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: theme.spacing.lg,
  },
  emptyTitle: {
    fontSize: theme.typography.fontSize.title,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
  },
  header: {
    paddingTop: theme.spacing.lg,
    paddingBottom: theme.spacing.md,
    paddingHorizontal: theme.spacing.lg,
    ...theme.shadows.sm,
  },
  title: {
    fontSize: theme.typography.fontSize.heading,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: theme.typography.fontSize.md,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    fontWeight: theme.typography.fontWeight.medium,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: theme.spacing.xl,
  },
  chartSection: {
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.xl,
  },
  chartTitle: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    marginBottom: theme.spacing.xs,
  },
  chartSubtitle: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.lg,
  },
  // Bar Chart
  barChartContainer: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.xl,
    padding: theme.spacing.lg,
    ...theme.shadows.md,
  },
  barRow: {
    marginBottom: theme.spacing.md,
  },
  barLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.xs,
  },
  barNumero: {
    fontSize: theme.typography.fontSize.md,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    width: 30,
  },
  barAnimalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: theme.spacing.sm,
  },
  barAnimalIcon: {
    fontSize: 14,
    marginRight: theme.spacing.xs,
  },
  barAnimal: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textSecondary,
  },
  barContainer: {
    height: 32,
    backgroundColor: theme.colors.backgroundDark,
    borderRadius: theme.borderRadius.md,
    overflow: 'hidden',
  },
  bar: {
    height: '100%',
    justifyContent: 'center',
    paddingHorizontal: theme.spacing.sm,
    minWidth: 40,
  },
  barValue: {
    fontSize: theme.typography.fontSize.sm,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textWhite,
  },
  // Pie Chart
  pieChartContainer: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.xl,
    padding: theme.spacing.lg,
    ...theme.shadows.md,
  },
  pieRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  pieColor: {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginRight: theme.spacing.sm,
  },
  pieInfo: {
    flex: 1,
  },
  pieLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  pieAnimalIcon: {
    fontSize: 14,
    marginRight: theme.spacing.xs,
  },
  pieLabel: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textPrimary,
    fontWeight: theme.typography.fontWeight.semibold,
  },
  pieValue: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.textSecondary,
    marginTop: 2,
  },
  pieBarContainer: {
    width: 80,
    height: 8,
    backgroundColor: theme.colors.backgroundDark,
    borderRadius: theme.borderRadius.sm,
    overflow: 'hidden',
    marginLeft: theme.spacing.sm,
  },
  pieBar: {
    height: '100%',
  },
  // Trend Chart
  trendContainer: {
    gap: theme.spacing.md,
  },
  trendCard: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.xl,
    padding: theme.spacing.lg,
    ...theme.shadows.md,
  },
  trendHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  trendNumero: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: theme.spacing.md,
  },
  trendNumeroText: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: theme.typography.fontWeight.extrabold,
    color: theme.colors.textWhite,
  },
  trendInfo: {
    flex: 1,
  },
  trendAnimal: {
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
  },
  trendFrecuencia: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textSecondary,
    marginTop: 2,
  },
  trendFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  trendIcon: {
    fontSize: 20,
    marginRight: theme.spacing.sm,
  },
  trendText: {
    fontSize: theme.typography.fontSize.sm,
    fontWeight: theme.typography.fontWeight.semibold,
  },
  // Timeline
  timelineCard: {
    borderRadius: theme.borderRadius.xl,
    padding: theme.spacing.xl,
    ...theme.shadows.lg,
  },
  timelineRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timelinePoint: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: theme.colors.textWhite,
    marginRight: theme.spacing.md,
  },
  timelineContent: {
    flex: 1,
  },
  timelineLabel: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textWhite,
    opacity: 0.8,
    fontWeight: theme.typography.fontWeight.medium,
  },
  timelineDate: {
    fontSize: theme.typography.fontSize.lg,
    color: theme.colors.textWhite,
    fontWeight: theme.typography.fontWeight.bold,
    marginTop: 2,
  },
  timelineLine: {
    width: 2,
    height: 40,
    backgroundColor: theme.colors.textWhite,
    opacity: 0.3,
    marginLeft: 7,
    marginVertical: theme.spacing.sm,
  },
  timelineStats: {
    marginLeft: 38,
    gap: theme.spacing.xs,
  },
  timelineStatsText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.textWhite,
    fontWeight: theme.typography.fontWeight.semibold,
  },
});
