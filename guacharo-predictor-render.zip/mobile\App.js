// mobile/App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

// Contexto de tema
import { ThemeProvider, useTheme } from './contexts/ThemeContext';

// Pantallas
import HomeScreen from './screens/HomeScreen';
import PredictScreen from './screens/PredictScreen';
import HistoryScreen from './screens/HistoryScreen';
import StatsScreen from './screens/StatsScreen';
import SettingsScreen from './screens/SettingsScreen';

const Tab = createBottomTabNavigator();

function AppNavigator() {
  const { colors, isDarkMode } = useTheme();

  return (
    <>
      <StatusBar style={isDarkMode ? 'light' : 'dark'} />
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName;
              if (route.name === 'Inicio') iconName = 'home';
              else if (route.name === 'Predecir') iconName = 'psychology';
              else if (route.name === 'Historial') iconName = 'history';
              else if (route.name === 'Estadísticas') iconName = 'bar-chart';
              else if (route.name === 'Ajustes') iconName = 'settings';
              return <MaterialIcons name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: colors.primary,
            tabBarInactiveTintColor: colors.textSecondary,
            headerStyle: { 
              backgroundColor: colors.surface,
              borderBottomColor: colors.border,
            },
            headerTintColor: colors.textPrimary,
            tabBarStyle: {
              backgroundColor: colors.surface,
              borderTopColor: colors.border,
              height: 60,
              paddingBottom: 8,
              paddingTop: 8,
            },
            tabBarLabelStyle: {
              fontSize: 12,
              fontWeight: '600',
            },
          })}
        >
          <Tab.Screen 
            name="Inicio" 
            component={HomeScreen}
            options={{ title: 'Inicio - Guácharo' }}
          />
          <Tab.Screen 
            name="Predecir" 
            component={PredictScreen}
            options={{ title: 'Generar Predicciones' }}
          />
          <Tab.Screen 
            name="Historial" 
            component={HistoryScreen}
            options={{ title: 'Historial Completo' }}
          />
          <Tab.Screen 
            name="Estadísticas" 
            component={StatsScreen}
            options={{ title: 'Estadísticas Avanzadas' }}
          />
          <Tab.Screen 
            name="Ajustes" 
            component={SettingsScreen}
            options={{ title: 'Configuración' }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <AppNavigator />
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
