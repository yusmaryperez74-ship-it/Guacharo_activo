﻿# 🚀 INSTRUCCIONES PARA RENDER

## 📋 Pasos para Desplegar

### 1. Subir a GitHub
1. Crea un repositorio público en GitHub
2. Sube todos estos archivos al repositorio

### 2. Configurar Render
1. Ve a https://render.com/
2. Crea cuenta con GitHub
3. New Web Service
4. Conecta tu repositorio

### 3. Configuración del Servicio
- **Name:** guacharo-predictor
- **Root Directory:** Backend
- **Environment:** Python 3
- **Build Command:** pip install -r requirements.txt
- **Start Command:** python app.py
- **Plan:** Free

### 4. Obtener URL
Una vez desplegado, obtendrás una URL como:
https://guacharo-predictor.onrender.com

### 5. Actualizar config.js
Edita mobile/config.js y cambia:
: "https://TU-URL.onrender.com"

### 6. Generar APK
cd mobile
eas build --platform android --profile production

¡El APK funcionará desde cualquier red!
