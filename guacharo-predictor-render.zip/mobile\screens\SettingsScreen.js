import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Switch
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import config from '../config';
import { useTheme } from '../contexts/ThemeContext';

export default function SettingsScreen() {
  const [autoUpdate, setAutoUpdate] = useState(false);
  const { isDarkMode, themeMode, toggleTheme, setAutoTheme, theme, colors } = useTheme();
  
  const handleThemeToggle = () => {
    toggleTheme();
  };
  
  const handleAutoTheme = () => {
    setAutoTheme();
    Alert.alert(
      '🌓 Tema Automático',
      'El tema se ajustará automáticamente según la configuración de tu dispositivo.',
      [{ text: 'OK' }]
    );
  };

  const actualizarDatos = () => {
    Alert.alert(
      '🔄 Actualizar Datos',
      'Para actualizar los datos, ejecuta en tu PC:\n\n' +
      '1. Abre PowerShell\n' +
      '2. cd Backend\n' +
      '3. .\\venv\\Scripts\\Activate.ps1\n' +
      '4. python data_update.py\n\n' +
      'Luego desliza hacia abajo en cualquier pantalla para refrescar.',
      [
        { text: 'Entendido', style: 'default' },
        {
          text: 'Copiar Comandos',
          onPress: () => {
            Alert.alert(
              'Comandos',
              'cd Backend\n.\\venv\\Scripts\\Activate.ps1\npython data_update.py'
            );
          }
        }
      ]
    );
  };

  const verificarConexion = async () => {
    try {
      // Crear un timeout manual
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch(`${config.API_URL}/api/health`, {
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);
      
      if (response.ok) {
        const data = await response.json();
        Alert.alert(
          '✅ Conexión Exitosa',
          `Backend funcionando correctamente\n\n` +
          `Estado: ${data.status}\n` +
          `URL: ${config.API_URL}`,
          [{ text: 'OK' }]
        );
      } else {
        throw new Error('Backend no responde correctamente');
      }
    } catch (error) {
      const errorMsg = error.name === 'AbortError' 
        ? 'Tiempo de espera agotado (5 segundos)'
        : error.message;
      
      Alert.alert(
        '❌ Error de Conexión',
        `No se puede conectar al backend:\n\n${errorMsg}\n\n` +
        `URL configurada: ${config.API_URL}\n\n` +
        `Verifica que:\n` +
        `1. El backend esté corriendo\n` +
        `2. Tu teléfono y PC estén en la misma red WiFi\n` +
        `3. La IP sea correcta`,
        [{ text: 'OK' }]
      );
    }
  };

  const limpiarCache = () => {
    Alert.alert(
      'Limpiar Caché',
      '¿Estás seguro de que quieres limpiar el caché de la app?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Limpiar',
          style: 'destructive',
          onPress: () => {
            // Aquí podrías implementar limpieza de AsyncStorage si lo usas
            Alert.alert('✅ Caché Limpiado', 'El caché se ha limpiado correctamente.');
          }
        }
      ]
    );
  };

  const acercaDe = () => {
    Alert.alert(
      'Acerca de',
      `🔮 Guácharo Predictor\n\n` +
      `Versión: 1.0.0\n` +
      `Desarrollado con React Native + Expo\n\n` +
      `Backend: Python/Flask\n` +
      `Modelo: Análisis Estadístico + Cadenas de Markov\n\n` +
      `© 2025 - Todos los derechos reservados`,
      [{ text: 'OK' }]
    );
  };

  const styles = createStyles(colors, theme);

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[colors.surface, colors.background]}
        style={styles.header}
      >
        <Text style={styles.headerIcon}>⚙️</Text>
        <Text style={styles.title}>Configuración</Text>
        <Text style={styles.subtitle}>Ajustes y preferencias</Text>
      </LinearGradient>

      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Sección: Datos */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 Datos</Text>

          <TouchableOpacity onPress={actualizarDatos}>
            <LinearGradient
              colors={theme.gradients.primary}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.button}
            >
              <Text style={styles.buttonIcon}>🔄</Text>
              <Text style={styles.buttonText}>Cómo Actualizar Datos</Text>
            </LinearGradient>
          </TouchableOpacity>

          <Text style={styles.buttonDescription}>
            Ver instrucciones para actualizar datos manualmente
          </Text>

          {/* Auto-actualización (futuro) */}
          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Auto-actualización</Text>
                <Text style={styles.settingDescription}>
                  Actualizar datos automáticamente al abrir la app
                </Text>
              </View>
              <Switch
                value={autoUpdate}
                onValueChange={setAutoUpdate}
                trackColor={{ false: colors.border, true: colors.primaryLight }}
                thumbColor={autoUpdate ? colors.primary : colors.surface}
              />
            </View>
          </View>
        </View>

        {/* Sección: Conexión */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🌐 Conexión</Text>

          <TouchableOpacity onPress={verificarConexion}>
            <View style={styles.buttonSecondary}>
              <Text style={styles.buttonIcon}>🔌</Text>
              <Text style={styles.buttonTextSecondary}>Verificar Conexión</Text>
            </View>
          </TouchableOpacity>

          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>🌐</Text>
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>URL del Backend</Text>
                <Text style={styles.infoValue}>{config.API_URL}</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Sección: Apariencia */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🎨 Apariencia</Text>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Modo Oscuro</Text>
                <Text style={styles.settingDescription}>
                  {themeMode === 'auto' 
                    ? 'Automático (según el sistema)' 
                    : isDarkMode 
                    ? 'Activado' 
                    : 'Desactivado'}
                </Text>
              </View>
              <Switch
                value={isDarkMode}
                onValueChange={handleThemeToggle}
                trackColor={{ false: colors.border, true: colors.primaryLight }}
                thumbColor={isDarkMode ? colors.primary : colors.surface}
              />
            </View>
          </View>

          {themeMode !== 'auto' && (
            <TouchableOpacity onPress={handleAutoTheme}>
              <View style={styles.buttonSecondary}>
                <Text style={styles.buttonIcon}>🌓</Text>
                <Text style={styles.buttonTextSecondary}>Usar Tema Automático</Text>
              </View>
            </TouchableOpacity>
          )}

          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>💡</Text>
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>Modo Actual</Text>
                <Text style={styles.infoValue}>
                  {themeMode === 'auto' ? 'Automático' : isDarkMode ? 'Oscuro' : 'Claro'}
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Sección: Aplicación */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📱 Aplicación</Text>

          <TouchableOpacity onPress={limpiarCache}>
            <View style={styles.buttonSecondary}>
              <Text style={styles.buttonIcon}>🗑️</Text>
              <Text style={styles.buttonTextSecondary}>Limpiar Caché</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity onPress={acercaDe}>
            <View style={styles.buttonSecondary}>
              <Text style={styles.buttonIcon}>ℹ️</Text>
              <Text style={styles.buttonTextSecondary}>Acerca de</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Información */}
        <View style={styles.footer}>
          <LinearGradient
            colors={theme.gradients.primary}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.footerCard}
          >
            <Text style={styles.footerIcon}>🔮</Text>
            <Text style={styles.footerText}>Guácharo Predictor</Text>
            <Text style={styles.footerVersion}>Versión 1.0.0</Text>
            <Text style={styles.footerSubtext}>
              Predicciones basadas en análisis estadístico
            </Text>
          </LinearGradient>
        </View>
      </ScrollView>
    </View>
  );
}

const createStyles = (colors, theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingTop: theme.spacing.xl,
    paddingBottom: theme.spacing.lg,
    paddingHorizontal: theme.spacing.lg,
    alignItems: 'center',
    ...theme.shadows.sm,
  },
  headerIcon: {
    fontSize: 48,
    marginBottom: theme.spacing.sm,
  },
  title: {
    fontSize: theme.typography.fontSize.display,
    fontWeight: theme.typography.fontWeight.bold,
    color: colors.textPrimary,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: theme.typography.fontSize.md,
    color: colors.textSecondary,
    marginTop: theme.spacing.xs,
    fontWeight: theme.typography.fontWeight.medium,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: theme.spacing.xl,
  },
  section: {
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.lg,
  },
  sectionTitle: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: theme.typography.fontWeight.bold,
    color: colors.textPrimary,
    marginBottom: theme.spacing.md,
    letterSpacing: -0.3,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: theme.spacing.lg,
    paddingHorizontal: theme.spacing.xl,
    borderRadius: theme.borderRadius.xl,
    marginBottom: theme.spacing.sm,
    ...theme.shadows.md,
  },
  buttonSecondary: {
    backgroundColor: colors.surface,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: theme.spacing.lg,
    paddingHorizontal: theme.spacing.xl,
    borderRadius: theme.borderRadius.xl,
    marginBottom: theme.spacing.md,
    borderWidth: 2,
    bordercolor: colors.primary,
    ...theme.shadows.sm,
  },
  buttonIcon: {
    fontSize: 22,
    marginRight: theme.spacing.sm,
  },
  buttonText: {
    color: colors.textWhite,
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.bold,
    letterSpacing: 0.3,
  },
  buttonTextSecondary: {
    color: colors.primary,
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.bold,
    letterSpacing: 0.3,
  },
  buttonDescription: {
    fontSize: theme.typography.fontSize.sm,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: theme.spacing.lg,
    lineHeight: 18,
  },
  settingCard: {
    backgroundColor: colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    ...theme.shadows.sm,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingInfo: {
    flex: 1,
    marginRight: theme.spacing.md,
  },
  settingTitle: {
    fontSize: theme.typography.fontSize.md,
    fontWeight: theme.typography.fontWeight.bold,
    color: colors.textPrimary,
    marginBottom: theme.spacing.xs,
  },
  settingDescription: {
    fontSize: theme.typography.fontSize.sm,
    color: colors.textSecondary,
    lineHeight: 18,
  },
  infoCard: {
    backgroundColor: colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    ...theme.shadows.sm,
    borderLeftWidth: 4,
    borderLeftcolor: colors.primary,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.md,
  },
  infoIcon: {
    fontSize: 28,
  },
  infoContent: {
    flex: 1,
  },
  infoLabel: {
    fontSize: theme.typography.fontSize.xs,
    color: colors.textSecondary,
    fontWeight: theme.typography.fontWeight.medium,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: theme.spacing.xs,
  },
  infoValue: {
    fontSize: theme.typography.fontSize.md,
    color: colors.textPrimary,
    fontWeight: theme.typography.fontWeight.bold,
  },
  footer: {
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.xl,
    paddingBottom: theme.spacing.lg,
  },
  footerCard: {
    borderRadius: theme.borderRadius.xl,
    padding: theme.spacing.xl,
    alignItems: 'center',
    ...theme.shadows.lg,
  },
  footerIcon: {
    fontSize: 48,
    marginBottom: theme.spacing.md,
  },
  footerText: {
    fontSize: theme.typography.fontSize.title,
    color: colors.textWhite,
    fontWeight: theme.typography.fontWeight.bold,
    marginBottom: theme.spacing.xs,
  },
  footerVersion: {
    fontSize: theme.typography.fontSize.sm,
    color: colors.textWhite,
    fontWeight: theme.typography.fontWeight.semibold,
    opacity: 0.9,
    marginBottom: theme.spacing.sm,
  },
  footerSubtext: {
    fontSize: theme.typography.fontSize.sm,
    color: colors.textWhite,
    textAlign: 'center',
    opacity: 0.8,
    lineHeight: 20,
  },
});

