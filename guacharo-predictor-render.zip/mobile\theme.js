// theme.js - Sistema de diseño centralizado

export const colors = {
  // Colores principales - Paleta Morada
  primary: '#8B5CF6',
  primaryDark: '#7C3AED',
  primaryLight: '#A78BFA',
  
  // Colores secundarios - Morado oscuro
  secondary: '#6D28D9',
  secondaryDark: '#5B21B6',
  secondaryLight: '#8B5CF6',
  
  // Colores de acento - Rosa/Magenta
  accent: '#EC4899',
  accentDark: '#DB2777',
  accentLight: '#F472B6',
  
  // Colores de estado
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#8B5CF6',
  
  // Colores de ranking
  gold: '#FCD34D',
  silver: '#D1D5DB',
  bronze: '#F97316',
  
  // Grises modernos con tinte morado
  background: '#FAF5FF',
  backgroundDark: '#F3E8FF',
  surface: '#FFFFFF',
  surfaceElevated: '#FFFFFF',
  border: '#E9D5FF',
  divider: '#DDD6FE',
  
  // Textos
  textPrimary: '#1F2937',
  textSecondary: '#6B7280',
  textDisabled: '#9CA3AF',
  textWhite: '#FFFFFF',
  
  // Transparencias
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.3)',
  
  // Colores especiales para animalitos
  animalBg: ['#8B5CF6', '#A78BFA', '#C4B5FD', '#DDD6FE', '#EC4899'],
};

export const gradients = {
  primary: ['#8B5CF6', '#A78BFA'],
  secondary: ['#6D28D9', '#8B5CF6'],
  accent: ['#EC4899', '#F472B6'],
  success: ['#10B981', '#34D399'],
  warning: ['#F59E0B', '#FBBF24'],
  error: ['#EF4444', '#F87171'],
  purple: ['#7C3AED', '#A78BFA'],
  purpleDark: ['#5B21B6', '#7C3AED'],
  purpleLight: ['#A78BFA', '#C4B5FD'],
  pink: ['#EC4899', '#F472B6'],
  magenta: ['#D946EF', '#F0ABFC'],
  // Gradientes especiales
  sunset: ['#EC4899', '#F59E0B'],
  royal: ['#6D28D9', '#8B5CF6'],
  mystic: ['#8B5CF6', '#EC4899'],
  gold: ['#FCD34D', '#F59E0B'],
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const borderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  round: 999,
};

export const typography = {
  // Tamaños de fuente
  fontSize: {
    xs: 10,
    sm: 12,
    md: 14,
    lg: 16,
    xl: 18,
    xxl: 20,
    title: 24,
    heading: 28,
    display: 32,
  },
  
  // Pesos de fuente
  fontWeight: {
    light: '300',
    regular: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
    extrabold: '800',
  },
  
  // Alturas de línea
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },
};

export const shadows = {
  none: {
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 3,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 5,
  },
  xl: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 8,
  },
  colored: {
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
};

export const animations = {
  duration: {
    fast: 150,
    normal: 300,
    slow: 500,
  },
  easing: {
    easeIn: 'ease-in',
    easeOut: 'ease-out',
    easeInOut: 'ease-in-out',
  },
};

// Estilos comunes reutilizables
export const commonStyles = {
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  
  card: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    ...shadows.md,
  },
  
  cardElevated: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.xl,
    padding: spacing.lg,
    ...shadows.lg,
  },
  
  button: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    ...shadows.sm,
  },
  
  buttonText: {
    color: colors.textWhite,
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.bold,
    letterSpacing: 0.5,
  },
  
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    fontSize: typography.fontSize.md,
    color: colors.textPrimary,
  },
  
  header: {
    backgroundColor: colors.surface,
    paddingTop: spacing.lg,
    paddingBottom: spacing.md,
    paddingHorizontal: spacing.lg,
    ...shadows.sm,
  },
  
  headerTitle: {
    fontSize: typography.fontSize.heading,
    fontWeight: typography.fontWeight.bold,
    color: colors.textPrimary,
    letterSpacing: -0.5,
  },
  
  sectionTitle: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.textPrimary,
    marginBottom: spacing.md,
    letterSpacing: -0.3,
  },
  
  badge: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.round,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
  },
  
  badgeText: {
    color: colors.textWhite,
    fontSize: typography.fontSize.sm,
    fontWeight: typography.fontWeight.bold,
    letterSpacing: 0.3,
  },
  
  // Componentes de número (para animalitos)
  numberCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.md,
  },
  
  numberText: {
    fontSize: typography.fontSize.display,
    fontWeight: typography.fontWeight.extrabold,
    color: colors.textWhite,
  },
};

// Tema Oscuro
export const darkColors = {
  // Colores principales - Morado más brillante para contraste
  primary: '#A78BFA',
  primaryDark: '#8B5CF6',
  primaryLight: '#C4B5FD',
  
  // Colores secundarios
  secondary: '#8B5CF6',
  secondaryDark: '#7C3AED',
  secondaryLight: '#A78BFA',
  
  // Colores de acento
  accent: '#F472B6',
  accentDark: '#EC4899',
  accentLight: '#F9A8D4',
  
  // Colores de estado
  success: '#34D399',
  warning: '#FBBF24',
  error: '#F87171',
  info: '#A78BFA',
  
  // Colores de ranking
  gold: '#FCD34D',
  silver: '#D1D5DB',
  bronze: '#F97316',
  
  // Fondos oscuros
  background: '#0F0F1E',
  backgroundDark: '#1A1A2E',
  surface: '#16213E',
  surfaceElevated: '#1F2937',
  border: '#374151',
  divider: '#4B5563',
  
  // Textos para fondo oscuro
  textPrimary: '#F9FAFB',
  textSecondary: '#D1D5DB',
  textDisabled: '#9CA3AF',
  textWhite: '#FFFFFF',
  
  // Transparencias
  overlay: 'rgba(0, 0, 0, 0.7)',
  overlayLight: 'rgba(0, 0, 0, 0.5)',
  
  // Colores especiales para animalitos
  animalBg: ['#8B5CF6', '#A78BFA', '#C4B5FD', '#DDD6FE', '#EC4899'],
};

export default {
  colors,
  darkColors,
  gradients,
  spacing,
  borderRadius,
  typography,
  shadows,
  animations,
  commonStyles,
};
