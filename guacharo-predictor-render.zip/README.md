﻿# 🔮 Guácharo Predictor

Aplicación móvil para predicciones de animalitos del Guácharo Activo con inteligencia artificial.

## 🚀 Características

- ✅ **Predicciones con IA** usando análisis estadístico y cadenas de Markov
- ✅ **Modo oscuro** completo con tema automático
- ✅ **Historial completo** con búsqueda y filtros
- ✅ **Estadísticas avanzadas** con gráficos
- ✅ **Actualización automática** de datos
- ✅ **Diseño moderno** con tema morado

## 📱 Tecnologías

### Backend
- **Python 3.11** + Flask
- **Pandas** para análisis de datos
- **BeautifulSoup** para web scraping
- **NumPy** para cálculos estadísticos

### Frontend
- **React Native** + Expo
- **React Navigation** para navegación
- **AsyncStorage** para persistencia
- **Linear Gradient** para diseño

## 🌐 Desplegar en Render

### Configuración del Web Service:
- **Root Directory:** Backend
- **Build Command:** pip install -r requirements.txt
- **Start Command:** python app.py
- **Environment:** Python 3

### Variables de entorno:
No se requieren variables especiales.

## 📦 Generar APK

`ash
cd mobile
npm install
eas build --platform android --profile production
`

## 📊 API Endpoints

- GET /api/health - Estado del servidor
- GET /api/history - Historial de resultados
- GET /api/predict - Predicciones con IA
- GET /api/stats - Estadísticas avanzadas

## 🔧 Configuración

El archivo mobile/config.js está configurado para:
- **Desarrollo:** IP local (Expo Go)
- **Producción:** URL de Render (APK)

Actualiza la URL de producción con tu URL de Render.

## 📄 Licencia

MIT License - Libre para uso personal y comercial.
